#!/bin/bash
test=$1
./solverB $test