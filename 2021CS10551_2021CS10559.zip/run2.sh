#!/bin/bash
test=$1
./mapperA $test