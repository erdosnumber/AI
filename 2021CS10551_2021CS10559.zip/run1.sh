#!/bin/bash
test=$1
./solverA $test
