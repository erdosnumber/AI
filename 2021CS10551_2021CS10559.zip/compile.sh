#!/bin/bash
g++ solverB.cpp -o solverB
g++ solverA.cpp -o solverA
g++ mapperA.cpp -o mapperA

